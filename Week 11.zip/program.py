import matematika

print("Luas Lingkaran")
r = float(input("Masukkan Jari-Jari: "))
luas = matematika.luas_lingkaran(r)
print("Luas Lingkaran:", luas)

print()
print("Luas Persegi")
s = float(input("Masukkan Sisi: "))
luas = matematika.luas_persegi(s)
print("Luas Persegi:", luas)