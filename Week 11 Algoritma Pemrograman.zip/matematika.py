import math

def luas_lingkaran(r):
    "Luas Lingkaran"
    luas = math.pi*r**2
    return luas

def luas_persegi(s):
    "Luas Persegi"
    luas = s**2
    return luas