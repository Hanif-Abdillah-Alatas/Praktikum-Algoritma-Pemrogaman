import matematika

def input_nilai(n):
    while True:
        nilai = input(n)
        if not nilai:
            print("Tidak Boleh Kosong")
        else:
            try:
                return float(nilai)
            except ValueError:
                print("Hanya Boleh Memasukkan Angka")

print("Luas Lingkaran")
r = input_nilai("Masukkan Jari-Jari: ")
luas = matematika.luas_lingkaran(r)
print("Luas Lingkaran:", luas)

print()
print("Luas Persegi")
s = input_nilai("Masukkan Sisi: ")
luas = matematika.luas_persegi(s)
print("Luas Persegi:", luas)